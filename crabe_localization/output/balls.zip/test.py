import cv2

empty = cv2.imread("empty.png")
b1 = cv2.imread("image_ball_1.png")